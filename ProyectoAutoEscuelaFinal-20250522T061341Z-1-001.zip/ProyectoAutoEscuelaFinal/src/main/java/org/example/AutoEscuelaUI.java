package org.example;

import javax.swing.*;
import java.awt.*;

public class AutoEscuelaUI extends JFrame {
    public AutoEscuelaUI() {
        setTitle("Gestor de Autoescuela Skibidi");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 450);
        setResizable(false);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.WHITE);

        JLabel welcomeLabel = new JLabel("Bienvenido a la Autoescuela Skibidi", SwingConstants.CENTER);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        mainPanel.add(welcomeLabel);

        String[] actions = {
                "Alumnos", "Instructores", "Clases Prácticas",
                "Tests", "Preguntas", "Resultados", "Notificaciones"
        };

        for (String action : actions) {
            JButton button = new JButton(action);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setMaximumSize(new Dimension(180, 30));
            button.setFont(new Font("Arial", Font.PLAIN, 15));
            button.addActionListener(e -> mostrarTabla(action));
            mainPanel.add(Box.createRigidArea(new Dimension(0, 8)));
            mainPanel.add(button);

            if (action.equals("Alumnos")) {
                JPanel alumnosPanel = new JPanel();
                alumnosPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
                alumnosPanel.setBackground(Color.WHITE);

                JButton addAlumnoBtn = new JButton("Añadir Alumno");
                addAlumnoBtn.setFont(new Font("Arial", Font.PLAIN, 13));
                addAlumnoBtn.addActionListener(ev -> mostrarDialogoAgregarAlumno());

                JTextField buscarField = new JTextField(10);
                buscarField.setFont(new Font("Arial", Font.PLAIN, 13));
                JButton buscarBtn = new JButton("Buscar");
                buscarBtn.setFont(new Font("Arial", Font.PLAIN, 13));
                buscarBtn.addActionListener(ev -> buscarAlumnoPorNombre(buscarField.getText()));

                alumnosPanel.add(addAlumnoBtn);
                alumnosPanel.add(new JLabel("Nombre:"));
                alumnosPanel.add(buscarField);
                alumnosPanel.add(buscarBtn);

                mainPanel.add(alumnosPanel);
            }
        }

        mainPanel.add(Box.createVerticalGlue());
        setContentPane(mainPanel);
    }

    private void mostrarTabla(String accion) {
        String query;
        switch (accion) {
            case "Alumnos":
                query = "SELECT * FROM Alumno";
                break;
            case "Instructores":
                query = "SELECT * FROM Instructor";
                break;
            case "Clases Prácticas":
                query = "SELECT * FROM ClasePractica";
                break;
            case "Tests":
                query = "SELECT * FROM Test";
                break;
            case "Preguntas":
                query = "SELECT * FROM Pregunta";
                break;
            case "Resultados":
                query = "SELECT * FROM Resultado";
                break;
            case "Notificaciones":
                query = "SELECT * FROM Notificacion";
                break;
            default:
                query = null;
        }
        if (query != null) {
            JFrame tablaFrame = new Tablas(accion, query);
            tablaFrame.setVisible(true);
        }
    }

    private void mostrarDialogoAgregarAlumno() {
        JTextField nombreField = new JTextField();
        JTextField apellidoField = new JTextField();
        Object[] message = {
                "Nombre:", nombreField, "Apellido:", apellidoField
        };
        int option = JOptionPane.showConfirmDialog(
                this, message, "Añadir Alumno", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText();
            String apellido = apellidoField.getText();
            JOptionPane.showMessageDialog(this, "Alumno añadido: " + nombre + " " + apellido);
        }
    }

    private void buscarAlumnoPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce un nombre para buscar.");
            return;
        }
        JFrame tablaFrame = new Tablas("Alumnos", "SELECT * FROM Alumno WHERE nombre LIKE '%" + nombre + "%'");
        tablaFrame.setVisible(true);
    }
}